package controllers;

import DAO.EventoDAO;
import Model.Evento;
import java.util.List;

public class EventoController {
     EventoDAO eDAO = new EventoDAO();
     
    public boolean editarEvento(Evento evento){
        return eDAO.editar(evento);
    }

    public void salvarEvento(Evento evento) {
        eDAO.salvar(evento);
    }
    
     public int excluir(Evento evento) {
        return eDAO.excluir(evento);
    }
     
    public List<Evento> listarEventos() {

        EventoDAO dao = new EventoDAO();

        return dao.listarTodos();
    }
    
    public Evento buscarEvento(int id) {

        EventoDAO dao = new EventoDAO();
        return dao.buscarPorId(id);
    }
    
    public List<Evento> buscarPorNome(String nome) {

        EventoDAO dao = new EventoDAO();
        return dao.buscarPorNome(nome);
    }
    
    public List<Evento> buscarEventosPorCliente(int idCliente) {

        EventoDAO dao = new EventoDAO();
        return dao.buscarPorCliente(idCliente);
    }
    
}
