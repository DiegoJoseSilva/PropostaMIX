package controllers;

import DAO.ClienteDAO;
import Model.Cliente;
import Model.Item;
import Service.ClienteService;
import Service.ItemService;
import java.util.List;
import javax.swing.JOptionPane;

public class ClienteController {
    
    ClienteDAO cDAO = new ClienteDAO();
    
    public Cliente salvarCliente(Cliente cliente) {
           return cDAO.salvar(cliente);
    }
    
    public boolean editarCliente(Cliente cliente){
        return cDAO.editar(cliente);
    }
    
    public int excluir(Cliente cliente) {
        ClienteService service = new ClienteService();
        return service.excluir(cliente);
    }
    
    public List<Cliente> buscarClientes(Cliente cliente){
        ClienteService service = new ClienteService();
        return service.buscarClientes(cliente);
    }
    
    public List<Cliente> listarClientes() {
        ClienteDAO dao = new ClienteDAO();
        return dao.listarTodos();
    }

    
}
