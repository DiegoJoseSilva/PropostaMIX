package controllers;

import Model.Cliente;
import Model.Item;
import Service.ClienteService;
import Service.ItemService;
import java.util.List;

public class ClienteController {
    public void salvarCliente(String nome, String cpf, String email, String Endereco, String telefone) {

        Cliente cliente = new Cliente();

        cliente.setNome(nome);
        cliente.setTelefone(telefone);

        ClienteService service = new ClienteService();

        service.salvar(cliente);
    }
    
    public void editarCliente(Cliente cliente){
        ClienteService service = new ClienteService();
        service.editar(cliente);
    }
    
    public int excluir(Cliente cliente) {
        ClienteService service = new ClienteService();
        return service.excluir(cliente);
    }
    
    public List<Cliente> buscarClientes(Cliente cliente){
        ClienteService service = new ClienteService();
        return service.buscarClientes(cliente);
    }

    
}
