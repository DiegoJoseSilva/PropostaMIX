package controllers;

import Model.Cliente;
import Model.Orcamento;
import java.util.List;

public class orcamentoController {

    public static List<Orcamento> buscarOrcamento(Cliente clienteCons) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
