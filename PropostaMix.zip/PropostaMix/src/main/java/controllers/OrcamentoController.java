package controllers;

import DAO.OrcamentoDAO;
import Model.Cliente;
import Model.Orcamento;
import java.util.List;

public class OrcamentoController {
    
    OrcamentoDAO oDAO = new OrcamentoDAO();

    public static List<Orcamento> buscarOrcamento(Cliente clienteCons) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public boolean atualizar(Orcamento orcamento) {
        return oDAO.atualizar(orcamento);
    }

    public List<Orcamento> listarPorCliente(int idCliente) {
        return oDAO.listarPorCliente(idCliente);
    }
    
}
