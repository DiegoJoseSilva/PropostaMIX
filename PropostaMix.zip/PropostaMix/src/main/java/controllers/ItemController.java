package controllers;


import Model.Cliente;
import Model.Item;
import Service.ItemService;
import java.util.List;

public class ItemController {
    public void salvarItem(String nome, String descricao, Double valor, String categoria) {

        Item item = new Item();

        item.setNome(nome);
        item.setDescricao(descricao);
        item.setValor(valor);
        item.setCategoria(categoria);
        
        
        
        ItemService service = new ItemService();

        service.salvar(item);
    }
    
    public void editarItem(Item item){
        ItemService service = new ItemService();
        service.editar(item);
    }
    
    public List<Item> buscarItens(Item item){
        ItemService service = new ItemService();
        return service.buscarItens(item);
    }

    public int excluir(Item item) {
        ItemService service = new ItemService();
        return service.excluir(item);
    }
    
}
