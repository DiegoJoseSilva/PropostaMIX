/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.propostamix;

/**
 *
 * @author diego
 */
public class PropostaMix {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
