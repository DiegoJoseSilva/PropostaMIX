package Model.contrato.Factory;

import Model.contrato.Clausulas.ClausulaLED;
import Model.contrato.Clausulas.ClausulaIluminacao;
import Model.ItemOrcamento;
import Model.Orcamento;
import Model.contrato.Clausulas.Clausula;
import Model.contrato.Clausulas.ClausulaAudio;
import Model.contrato.Clausulas.ClausulaBase;
import Model.contrato.Clausulas.ClausulaEstrutura;
import Model.contrato.Enums.CategoriaEquipamento;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClausulaFactory {
     public static List<Clausula> criar(Orcamento orcamento) {

        Set<CategoriaEquipamento> categorias = new HashSet<>();
        
        for (ItemOrcamento itemOrcamento : orcamento.getItens()) {
            
            CategoriaEquipamento categoria = CategoriaEquipamento.fromString(itemOrcamento.getItem().getCategoria());

            System.out.println("Enum: " + categoria);

            categorias.add(categoria);
            
            
            if (itemOrcamento.getItem() == null) {
                continue;
            }

            categorias.add(
                CategoriaEquipamento.fromString(
                    itemOrcamento.getItem().getCategoria()
                )
            );
        }

        List<Clausula> clausulas = new ArrayList<>();

        // Cláusula obrigatória
        clausulas.add(new ClausulaBase());

        // Cláusulas específicas
        if (categorias.contains(CategoriaEquipamento.AUDIO)) {
            clausulas.add(new ClausulaAudio());
        }

        if (categorias.contains(CategoriaEquipamento.ILUMINACAO)) {
            clausulas.add(new ClausulaIluminacao());
        }

        if (categorias.contains(CategoriaEquipamento.LED)) {
            clausulas.add(new ClausulaLED());
        }

        if (categorias.contains(CategoriaEquipamento.ESTRUTURA)) {
            clausulas.add(new ClausulaEstrutura());
        }

        return clausulas;
    }
}
