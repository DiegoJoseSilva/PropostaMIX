package Model.contrato.Clausulas;


public class ClausulaIluminacao implements Clausula{
    @Override
    public String gerar() {
        return """
        ILUMINAÇÃO:

        - Rede elétrica exclusiva recomendada
        - Proteção contra sobrecarga
        - Estabilidade de energia obrigatória
        """;
    }
}
