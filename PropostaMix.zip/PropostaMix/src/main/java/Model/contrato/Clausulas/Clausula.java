package Model.contrato.Clausulas;

public interface Clausula {
     String gerar();
}
