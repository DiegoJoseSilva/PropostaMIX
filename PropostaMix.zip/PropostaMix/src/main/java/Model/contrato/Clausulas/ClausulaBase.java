package Model.contrato.Clausulas;

public class ClausulaBase implements Clausula {
     @Override
    public String gerar() {
        return """
        CLÁUSULA GERAL:

        - O cliente é responsável pela segurança do local
        - Danos por uso inadequado serão cobrados
        - Cancelamento segue política da empresa
        """;
    }
}
