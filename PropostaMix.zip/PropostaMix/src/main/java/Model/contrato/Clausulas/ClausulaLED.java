package Model.contrato.Clausulas;

public class ClausulaLED implements Clausula{
    @Override
    public String gerar() {
        return """
        CLÁUSULA - PAINEL DE LED

        A LOCATÁRIA deverá fornecer:
        - Estrutura adequada para fixação dos painéis
        - Proteção contra vento, chuva e calor
        - Energia estabilizada

        Danos por mau uso ou condições climáticas são responsabilidade da LOCATÁRIA.
        """;
    }
}
