package Model.contrato.Clausulas;

public class ClausulaEstrutura implements Clausula{  

    @Override
    public String gerar() {
        return """
        ESTRUTURA:

        - Solo nivelado e seguro
        - Liberação para montagem antecipada
        - Responsabilidade por danos estruturais do local
        """;
    }
}
