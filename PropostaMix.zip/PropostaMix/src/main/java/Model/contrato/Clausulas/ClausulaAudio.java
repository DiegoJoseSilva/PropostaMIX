package Model.contrato.Clausulas;


public class ClausulaAudio implements Clausula {
    @Override
    public String gerar() {
        return """
        SISTEMA DE ÁUDIO:

        - Energia estável obrigatória (110V/220V)
        - Aterramento adequado
        - Operação sob responsabilidade do contratante local
        """;
    }
}
