package Service;

import DAO.ClienteDAO;
import Model.Cliente;
import java.util.List;

public class ClienteService {
    
    ClienteDAO cDao = new ClienteDAO();
    
    public void salvar(Cliente cliente) {

        if(cliente.getNome().isEmpty()) {
            throw new RuntimeException("Nome obrigatório");
        }

        cDao.salvar(cliente);
    }
    
    public void editar(Cliente cliente) {
        cDao.editar(cliente);
    }
    
    public int excluir(Cliente cliente) {
        return cDao.excluir(cliente);
    }

    public List<Cliente> buscarClientes(Cliente cliente) {
        return cDao.buscarClientes(cliente);
    }

    
    
    
}
