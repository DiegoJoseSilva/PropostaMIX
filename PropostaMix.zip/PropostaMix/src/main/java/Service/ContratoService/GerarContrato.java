package Service.ContratoService;

import Model.Orcamento;
import Model.contrato.Clausulas.Clausula;
import Model.contrato.Factory.ClausulaFactory;
import java.util.List;

public class GerarContrato {

    public String gerarContrato(Orcamento orcamento) {

        StringBuilder contrato = new StringBuilder();

        contrato.append("""
                         CONTRATO DE LOCAÇÃO

                         """);

        contrato.append(new IdentificacaoPartes().gerar(orcamento));
        contrato.append(new ObjetoDoContrato().gerar(orcamento));
        contrato.append(new ItensDaLocacao().gerar(orcamento));
        contrato.append(new Clausulas().gerar(orcamento));
        contrato.append(new Finalizacao().gerar(orcamento));

        return contrato.toString();
    }
}
