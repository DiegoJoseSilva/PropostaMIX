package Service.ContratoService;

import Model.Orcamento;

public class ObjetoDoContrato implements SecaoContrato {
    @Override
    public String gerar(Orcamento o) {

        return """
               2. OBJETO DO CONTRATO

               O presente contrato tem como objeto a locação de equipamentos
               para realização de evento em %s.

               """
               .formatted(
                       o.getEvento().getLocalEvento()
               );
    }
}
