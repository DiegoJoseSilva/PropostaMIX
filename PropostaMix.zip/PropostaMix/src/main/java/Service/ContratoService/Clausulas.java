package Service.ContratoService;

import Model.Orcamento;
import Model.contrato.Clausulas.Clausula;
import Model.contrato.Factory.ClausulaFactory;
import java.util.List;

public class Clausulas implements SecaoContrato {

    @Override
    public String gerar(Orcamento o) {

        StringBuilder sb = new StringBuilder();

        for(Clausula c : ClausulaFactory.criar(o)) {
            sb.append(c.gerar());
            sb.append("\n\n");
        }

        return sb.toString();
    }
}
