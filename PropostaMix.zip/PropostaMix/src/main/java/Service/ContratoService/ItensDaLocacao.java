package Service.ContratoService;

import Model.ItemOrcamento;
import Model.Orcamento;

public class ItensDaLocacao implements SecaoContrato {
     @Override
    public String gerar(Orcamento o) {

        StringBuilder sb = new StringBuilder();

        sb.append("""
                  3. ITENS DA LOCAÇÃO

                  Conforme orçamento aprovado:

                  """);

        for(ItemOrcamento item : o.getItens()) {

            sb.append("- ")
              .append(item.getItem().getDescricao())
              .append("\n");
        }

        sb.append("\n");

        return sb.toString();
    }
}
