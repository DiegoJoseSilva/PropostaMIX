package Service.ContratoService;

import Model.Orcamento;

public interface SecaoContrato {
    String gerar(Orcamento orcamento);
}

