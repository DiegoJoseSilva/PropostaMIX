package Service;

import Model.Orcamento;

public class ContratoService {
    public String gerarContrato(Orcamento orcamento) {
        return "CONTRATO DE PRESTAÇÃO DE SERVIÇOS\n\n" +
               "Cliente: " + orcamento.getCliente().getNome() + "\n" +
               "Local: " + orcamento.getLocal().getNome() + "\n" +
               "Data: " + orcamento.getDataEvento() + "\n" +
               "Valor Total: R$ " + orcamento.getValorTotal() + "\n\n" +
               "Cláusulas:\n" +
               "1. O contratante se compromete...\n" +
               "2. O contratado fornecerá os equipamentos...\n";
    }
}
