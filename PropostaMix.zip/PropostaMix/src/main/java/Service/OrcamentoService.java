package Service;

import Model.OrcamentoItem;
import java.util.List;

public class OrcamentoService {
    public double calcularTotal(List<OrcamentoItem> itens) {
        double total = 0;

        for (OrcamentoItem item : itens) {
            total += item.getQuantidade() * item.getValorUnitario();
        }

        return total;
    }
}
