package Service;

import DAO.ItemDAO;
import Model.Item;
import java.util.List;

public class ItemService {
   
     ItemDAO idao = new ItemDAO();
    
    public void salvar(Item item) {

        if(item.getNome().isEmpty()) {
            throw new RuntimeException("Nome obrigatório");
        }
        idao.salvar(item);
    }
    
    public void editar(Item item) {
        idao.editar(item);
    }
    
    public List<Item> buscarItens(Item item) {
        return idao.buscarItens(item);
    }   
    
    public List<Item> buscarItens() {
        return idao.buscarItens();
    } 

    public int excluir(Item item) {
        return idao.excluirItem(item);
    }
}
