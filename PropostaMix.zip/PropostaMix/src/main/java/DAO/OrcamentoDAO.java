package DAO;

import Model.Cliente;
import Model.Evento;
import Model.Orcamento;
import Util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class OrcamentoDAO {
    
    
    Connection conn;
    
    public OrcamentoDAO(){
        conn = new Conexao().conectar();
    }
    
    
    public Orcamento salvar(Orcamento orcamento) {
        
        try {

            PreparedStatement stmt = conn.prepareStatement(
                """
                INSERT INTO orcamento
                (cliente_id, evento_id, data_criacao,
                 subtotal, desconto, valor_total,
                 forma_pagamento, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                Statement.RETURN_GENERATED_KEYS
            );

            stmt.setInt(1,
                    orcamento.getCliente().getId());

            stmt.setInt(2,
                    orcamento.getEvento().getId());

            stmt.setTimestamp(3,
                    Timestamp.valueOf(
                            orcamento.getDataCriacao()));

            stmt.setDouble(4,
                    orcamento.getSubtotal());

            stmt.setDouble(5,
                    orcamento.getDesconto());

            stmt.setDouble(6,
                    orcamento.getValorTotal());

            stmt.setString(7,
                    orcamento.getFormaPagamento());

            stmt.setString(8,
                    orcamento.getStatus());

            stmt.executeUpdate();

            ResultSet rs =
                    stmt.getGeneratedKeys();

            if (rs.next()) {
                orcamento.setId(
                        rs.getInt("id"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return orcamento;
    }
    
    public boolean editar(Orcamento orcamento) {

        try {

            PreparedStatement stmt =
                    conn.prepareStatement(
                            """
                            UPDATE orcamento
                            SET cliente_id = ?,
                                evento_id = ?,
                                subtotal = ?,
                                desconto = ?,
                                valor_total = ?,
                                forma_pagamento = ?,
                                status = ?
                            WHERE id = ?
                            """
                    );

            stmt.setInt(1,
                    orcamento.getCliente().getId());

            stmt.setInt(2,
                    orcamento.getEvento().getId());

            stmt.setDouble(3,
                    orcamento.getSubtotal());

            stmt.setDouble(4,
                    orcamento.getDesconto());

            stmt.setDouble(5,
                    orcamento.getValorTotal());

            stmt.setString(6,
                    orcamento.getFormaPagamento());

            stmt.setString(7,
                    orcamento.getStatus());

            stmt.setInt(8,
                    orcamento.getId());

            stmt.executeUpdate();

            return true;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public boolean excluir(int id) {

        try {

            PreparedStatement stmt =
                    conn.prepareStatement(
                            """
                            DELETE FROM orcamento
                            WHERE id = ?
                            """
                    );

            stmt.setInt(1, id);

            stmt.executeUpdate();

            return true;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public List<Orcamento> listarTodos() {

        List<Orcamento> lista = new ArrayList<>();

        try {

            PreparedStatement stmt =
                    conn.prepareStatement(
                            """
                            SELECT o.*,
                                   c.nome AS nome_cliente,
                                   e.nome AS nome_evento
                            FROM orcamento o
                            INNER JOIN cliente c
                                ON c.id = o.cliente_id
                            INNER JOIN evento e
                                ON e.id = o.evento_id
                            ORDER BY o.id
                            """
                    );

            ResultSet rs =
                    stmt.executeQuery();

            while (rs.next()) {

                lista.add(getOrcamento(rs));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return lista;
    }
    
    public Orcamento buscarPorId(int id) {

        Orcamento orcamento = null;

        try {

            PreparedStatement stmt =
                    conn.prepareStatement(
                            """
                            SELECT o.*,
                                   c.nome AS nome_cliente,
                                   e.nome AS nome_evento
                            FROM orcamento o
                            INNER JOIN cliente c
                                ON c.id = o.cliente_id
                            INNER JOIN evento e
                                ON e.id = o.evento_id
                            WHERE o.id = ?
                            """
                    );

            stmt.setInt(1, id);

            ResultSet rs =
                    stmt.executeQuery();

            if (rs.next()) {

                orcamento = getOrcamento(rs);

                // futuramente
                // carregar itens

                OrcamentoItemDAO itemDAO = new OrcamentoItemDAO();

                orcamento.setItens(itemDAO.listarPorOrcamento(orcamento.getId()));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    return orcamento;
    }
    
    private Orcamento getOrcamento(ResultSet rs)throws SQLException {

        Orcamento o = new Orcamento();

        Cliente cliente = new Cliente();

        Evento evento = new Evento();

        cliente.setId(rs.getInt("cliente_id"));

        cliente.setNome(rs.getString("nome_cliente"));

        evento.setId(rs.getInt("evento_id"));

        evento.setNome(rs.getString("nome_evento"));

        o.setId(rs.getInt("id"));

        o.setCliente(cliente);

        o.setEvento(evento);

        o.setDataCriacao(rs.getTimestamp("data_criacao").toLocalDateTime());

        o.setSubtotal(rs.getDouble("subtotal"));

        o.setDesconto(rs.getDouble("desconto"));

        o.setValorTotal(rs.getDouble("valor_total"));

        o.setFormaPagamento(rs.getString("forma_pagamento"));

        o.setStatus(rs.getString("status"));

        return o;
    }
    
}
