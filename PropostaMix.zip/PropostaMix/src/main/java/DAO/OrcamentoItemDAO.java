package DAO;

import Model.ItemOrcamento;
import Util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrcamentoItemDAO {

    Connection conn;

    public OrcamentoItemDAO() {
        conn = new Conexao().conectar();
    }

    public boolean salvar(ItemOrcamento item) {

        try {

            PreparedStatement stmt =
                    conn.prepareStatement(
                            """
                            INSERT INTO orcamento_item
                            (
                                orcamento_id,
                                item_id,
                                quantidade,
                                valor_unitario,
                                subtotal
                            )
                            VALUES (?, ?, ?, ?, ?)
                            """
                    );

            stmt.setInt(
                    1,
                    item.getOrcamento().getId());

            stmt.setInt(
                    2,
                    item.getItem().getId());

            stmt.setInt(
                    3,
                    item.getQuantidade());

            stmt.setDouble(
                    4,
                    item.getValorUnitario());

            stmt.setDouble(
                    5,
                    item.getSubtotal());

            stmt.executeUpdate();

            return true;

        } catch (SQLException ex) {

            ex.printStackTrace();
            return false;
        }
    }
    
    public List<ItemOrcamento> listarPorOrcamento(int idOrcamento) {

        return new ArrayList<>();
    }
}
