package DAO;

import Model.Cliente;
import Model.Evento;
import Util.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class EventoDAO {
    private Connection conn;

    public EventoDAO() {
        conn = new Conexao().conectar();
    }
    
    public Evento salvar(Evento evento) {

        try {

            PreparedStatement stmt = conn.prepareStatement(
                """
                INSERT INTO evento
                (cliente_id, nome, data_evento, horario,
                 local_evento, cidade, publico_estimado, observacoes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                Statement.RETURN_GENERATED_KEYS
            );

            stmt.setInt(1, evento.getCliente().getId());
            stmt.setString(2, evento.getNome());
            stmt.setDate(3, Date.valueOf(evento.getDataEvento()));
            stmt.setTime(4, Time.valueOf(evento.getHorario()));
            stmt.setString(5, evento.getLocalEvento());
            stmt.setString(6, evento.getCidade());
            stmt.setInt(7, evento.getPublicoEstimado());
            stmt.setString(8, evento.getObservacoes());

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();

            if(rs.next()){
                evento.setId(rs.getInt(1));
            }

        } catch(SQLException ex){
            ex.printStackTrace();
            evento.setId(-1);
        }

        return evento;
    }
    
    public boolean editar(Evento evento) {

        try {

            PreparedStatement stmt = conn.prepareStatement(
                """
                UPDATE evento
                SET cliente_id=?,
                    nome=?,
                    data_evento=?,
                    horario=?,
                    local_evento=?,
                    cidade=?,
                    publico_estimado=?,
                    observacoes=?
                WHERE id=?
                """
            );

            stmt.setInt(1, evento.getCliente().getId());
            stmt.setString(2, evento.getNome());
            stmt.setDate(3, Date.valueOf(evento.getDataEvento()));
            stmt.setTime(4, Time.valueOf(evento.getHorario()));
            stmt.setString(5, evento.getLocalEvento());
            stmt.setString(6, evento.getCidade());
            stmt.setInt(7, evento.getPublicoEstimado());
            stmt.setString(8, evento.getObservacoes());
            stmt.setInt(9, evento.getId());

            stmt.executeUpdate();

            return true;

        } catch(SQLException ex){
            ex.printStackTrace();
            return false;
        }
    }
    
    public int excluir(Evento e) {
        int verif = 0;
        try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM evento WHERE id=?", Statement.RETURN_GENERATED_KEYS);

            stmt.setInt(1, e.getId());
            verif = stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            
            if(rs.next()){
                e.setId(rs.getInt("id"));
            }
            else{
                e.setId(-1);
            }
        } catch(SQLException ex){
            ex.printStackTrace();
        }
        return verif;
    }
    
    public List<Evento> listarTodos() {

        List<Evento> lista = new ArrayList<>();

        try {

            PreparedStatement stmt = conn.prepareStatement(
                """
                SELECT e.*,
                       c.nome as nome_cliente
                FROM evento e
                INNER JOIN cliente c
                    ON e.cliente_id = c.id
                ORDER BY e.id
                """
            );

            ResultSet rs = stmt.executeQuery();

            while(rs.next()){

                Evento evento = new Evento();

                Cliente cliente = new Cliente();

                cliente.setId(rs.getInt("cliente_id"));
                cliente.setNome(rs.getString("nome_cliente"));

                evento.setId(rs.getInt("id"));
                evento.setCliente(cliente);
                evento.setNome(rs.getString("nome"));
                evento.setDataEvento(
                    rs.getDate("data_evento").toLocalDate()
                );

                lista.add(evento);
            }

        } catch(SQLException ex){
            ex.printStackTrace();
        }

        return lista;
    }
    
    public Evento buscarPorId(int id) {

        Evento evento = null;

        try {

            PreparedStatement stmt = conn.prepareStatement(
                """
                SELECT e.*, c.nome AS nome_cliente
                FROM evento e
                INNER JOIN cliente c
                    ON e.cliente_id = c.id
                WHERE e.id = ?
                """
            );

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                evento = new Evento();

                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("cliente_id"));
                cliente.setNome(rs.getString("nome_cliente"));

                evento.setCliente(cliente);

                evento.setId(rs.getInt("id"));
                evento.setNome(rs.getString("nome"));

                evento.setDataEvento(
                    rs.getDate("data_evento").toLocalDate()
                );

                if (rs.getTime("horario") != null) {
                    evento.setHorario(
                        rs.getTime("horario").toLocalTime()
                    );
                }

                evento.setLocalEvento(
                    rs.getString("local_evento")
                );

                evento.setCidade(
                    rs.getString("cidade")
                );

                
                evento.setPublicoEstimado(
                    rs.getInt("publico_estimado")
                );

                
                evento.setObservacoes(
                    rs.getString("observacoes")
                );
        }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return evento;
    }
    
    public List<Evento> buscarPorNome(String nome) {

        List<Evento> lista = new ArrayList<>();

        try {

            PreparedStatement stmt =
                conn.prepareStatement(
                    """
                    SELECT e.*, c.nome AS nome_cliente
                    FROM evento e
                    INNER JOIN cliente c
                        ON e.cliente_id = c.id
                    WHERE UPPER(e.nome)
                        LIKE UPPER(?)
                    ORDER BY e.nome
                    """
                );

            stmt.setString(1, "%" + nome + "%");

            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {

                Evento evento = new Evento();
                Cliente cliente = new Cliente();

                cliente.setId(rs.getInt("cliente_id"));
                cliente.setNome(rs.getString("nome_cliente"));
                evento.setCliente(cliente);

                evento.setId(
                    rs.getInt("id"));

                evento.setNome(
                    rs.getString("nome"));

                evento.setDataEvento(
                    rs.getDate("data_evento")
                      .toLocalDate());

                evento.setLocalEvento(
                    rs.getString("local_evento"));

                lista.add(evento);
            }

        } catch(SQLException ex) {
            ex.printStackTrace();
        }

        return lista;
    }
    
    public List<Evento> buscarPorCliente(int idCliente) {

        List<Evento> lista = new ArrayList<>();

        String sql = "SELECT e.*, c.nome AS nome_cliente FROM evento e INNER JOIN cliente c ON e.cliente_id = c.id WHERE e.cliente_id = ?";

        try {

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idCliente);

            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {

                Evento evento = new Evento();
                
                evento.setId(rs.getInt("id"));
                evento.setNome(rs.getString("nome"));
                evento.setDataEvento(rs.getDate("data_evento").toLocalDate());
                evento.setHorario(rs.getTime("horario").toLocalTime());
                evento.setLocalEvento(rs.getString("local_evento"));
                
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("cliente_id"));
                cliente.setNome(rs.getString("nome_cliente"));

                evento.setCliente(cliente);
                lista.add(evento);
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return lista;
    }
    
}
